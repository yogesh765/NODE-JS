# TravelBuddy
This is a basic travel website using HTML &amp; CSS in Frontend and NodeJS, ExpressJS and MongoDb as Backend

Video Link: https://drive.google.com/file/d/1l9Ra93v6c9oW4kmDSlmy7hyAEPgXgthf/view?usp=sharing
